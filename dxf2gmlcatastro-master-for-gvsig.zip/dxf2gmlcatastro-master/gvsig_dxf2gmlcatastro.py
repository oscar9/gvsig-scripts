
"""
Nombre:
dxfparcela2gmlcatastro.py
Autor:
Patricio Soriano :: SIGdeletras.com
Descripci�n:
El script general el correspondiente fichero GML de parcela catastral seg�n las
especificaciones de Castastro.
Especificaciones:
    - http://www.catastro.minhap.gob.es/esp/formatos_intercambio.asp
Requisistos:
- Es necesario tener instalado Python y GDAL
- El archivo DXF debe ser copiado en la misma ruta que los archivos .py
"""

import sys

from org.gdal.ogr import ogr
from org.gdal import gdal

from gvsig_plantillacatastro import *

import os.path
from gvsig import *


def crea_gml(dxffile, tempgml):
    """ Primera l�nea de documentaci�n define la funci�n
    
    Siguientes l�neas completan el resto de la documentaci�n y declaran los inputs y outputs.
    Genera el archivo GML seg�n el est�ndar de catastro y a�ade la primera parte
    del texto 
    """
    #Registramos todos los drivers de ogr
    ogr.RegisterAll()
    
    # Accede mediante GDAL al archivo DXF
    driver = ogr.GetDriverByName('DXF')
    data_source = driver.Open(dxffile, 0)
    layer = data_source.GetLayer(0)
  
    with open(tempgml, 'w') as filegml:
        filegml.writelines(PLANTILLA_1)
  
        print("El archivo %s contiene %i geometria." % (dxffile, layer.GetFeatureCount()))
  
        for n in range(0, layer.GetFeatureCount()):
            feature = layer.GetFeature(n)
            geom = feature.GetGeometryRef()
        
            area = geom.Area()
            print('El area del poligono es %.4f m2.' % (area))
        
            filegml.writelines(str(area))  # A�ade �rea al GML
        
            perimetro = geom.GetGeometryRef(0)
            print('Total de vertices del poligono: %s' % (perimetro.GetPointCount()))
            print('Listado de coordenadas:\nid,x,y')
  
            filegml.writelines(PLANTILLA_2)  # A�ade texto tras �rea
  
            for i in range(0, perimetro.GetPointCount()):
                pt = perimetro.GetPoint(i)
                coordlist = [str(pt[0]), ' ', str(pt[1]), '\n']
          
                filegml.writelines(coordlist)  # A�ade listado de coordenadas X e Y
          
                print("%i,%.4f,%.4f" % (i, pt[0], pt[1]))
  
        filegml.writelines(PLANTILLA_3)


def main(*args):

  # Dxffile: ficheroque se encuentra en la carpeta del script
  # se une path_dxffile + dxfile
  # por ejemplo:
  # dxffile = "p.dxf"
  # path_dxffile = r"C:/temp/"
  # Resultado es el path: C:/temp/p.dxf
  
  dxffile = "parcelacad.dxf"
  path_dxffile = script.getResource("").getAbsolutePath() #Ruta a nuestra carpeta en los scripts de gvSIG

  
  #Ruta con el path completo del fichero 
  fullpath_dxffile = os.path.join(path_dxffile, dxffile)

  #Fichero gml que se creara
  tempgml = r'C:/temp/gmlcatastro001.gml'



  # Proceso:
  # Comprueba que parcelacad.dxf existe en el mismo directorio
  if os.path.isfile(fullpath_dxffile):
    print("Archivo %s existente." % (fullpath_dxffile))
    
  else:
    print("No existe el fichero %s. A��dalo en la misma carpeta que los scripts de Python." % (fullpath_dxffile))

    return

  crea_gml(fullpath_dxffile, tempgml)