import gvsig
from uselib import use_plugin
use_plugin("org.gvsig.jexcel.app.mainplugin")

from jxl import Workbook
from jxl.write import Label, Number
from java.io import File
from java.util import Date
import time, os

from libs.formpanel import FormPanel

class ToolTest1(FormPanel):
    def __init__(self):
        FormPanel.__init__(self, script.getResource("exportExcel.xml"))
        print "All loaded!"
        
    def btnExport_click(self, *args):
        print "Export.."
        ExcelExport()
        print "Exported"
  
def ExcelExport(layer=None):
    templateExcel = r"C:/Reports/file10.xls"
    pathReports = r"C:/Reports"
    if layer==None:
        layer = gvsig.currentLayer()
    timestr = time.strftime("%Y%m%d-%H%M%S")

    fileWb = templateExcel
    fileOutput = ("%s_Point.xls") % (timestr) 
    
    print "\nWorkbook", fileOutput
    
    fileWbOutput = os.path.join(pathReports,fileOutput)
    
    workbook = Workbook.getWorkbook(File(fileWb))
    copy = Workbook.createWorkbook(File(fileWbOutput), workbook)
    
    features = layer.features()
    schema = []
    for i in layer.getSchema().getAttrNames():
        shtype = layer.getSchema().get(i).getDataTypeName()
        if not i == 'GEOMETRY':
            schema.append({"shname":i, "shtype":shtype})
        
    lenSchema = len(schema)
    sheet = copy.getSheet(0)

    n = 0 # start point header
    for i in range(0, lenSchema):
        label = Label(i, n, schema[i]["shname"])
        sheet.addCell(label)

    n = 1 #start row values
    for f in features:
        for i in range(0, lenSchema):
            val = f.get(schema[i]["shname"])
            typ = schema[i]["shtype"]

            #All number types check expresion
            if typ == "Integer" or typ == "Double" or typ == "Long":
                if val <= 0:
                    val = "-"
                    number = Label(i, n, val)
                    sheet.addCell(number)
                    continue
            
            if typ == "Integer":  
                number = Number(i, n, int(val))
            elif typ == "Double" or typ == "Long": 
                number = Number(i, n, float(val))
            elif typ == "String": 
                number = Label(i, n, val)
            else:                 
                print "not type set: pass as string",schema[i]["shname"],str(val),typ
                number = Label(i, n, str(val))
            sheet.addCell(number)
        n += 1
        
    
    copy.write()
    copy.close()

def main(*args):

  l = ToolTest1()
  l.showTool("Export")
  pass
